it('works',() =>{
	cy.visit('/').contains('Enviroment:Acceptance');
})
  